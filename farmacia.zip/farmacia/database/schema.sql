﻿-- Esquema de Base de Datos - Sistema Farmacia UTS
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS farmacia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farmacia;

CREATE TABLE roles (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(50) NOT NULL UNIQUE);
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
    nombre_completo VARCHAR(150) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE, rol_id INT NOT NULL, activo TINYINT(1) DEFAULT 1,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);
CREATE TABLE categorias (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(100) NOT NULL UNIQUE, activo TINYINT(1) DEFAULT 1);
CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(50) NOT NULL UNIQUE, nombre VARCHAR(200) NOT NULL,
    categoria_id INT, precio_venta DECIMAL(12,2) NOT NULL DEFAULT 0.00, stock_minimo INT DEFAULT 10,
    requiere_formula TINYINT(1) DEFAULT 0, activo TINYINT(1) DEFAULT 1,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);
CREATE TABLE ventas (
    id INT AUTO_INCREMENT PRIMARY KEY, numero_venta VARCHAR(30) NOT NULL UNIQUE, usuario_id INT NOT NULL,
    fecha_venta DATETIME NOT NULL, total DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Datos iniciales
INSERT INTO roles (nombre) VALUES ('Administrador'), ('Vendedor');
-- Hash BCrypt para 'admin123'
INSERT INTO usuarios (username, password, nombre_completo, email, rol_id) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador del Sistema', 'admin@farmacia.com', 1);
INSERT INTO categorias (nombre) VALUES ('Analgésicos'), ('Antibióticos'), ('Vitaminas');
INSERT INTO productos (codigo, nombre, categoria_id, precio_venta, stock_minimo) VALUES 
('ACET-500', 'Acetaminofén 500mg', 1, 8000.00, 50),
('AMO-500', 'Amoxicilina 500mg', 2, 18000.00, 20);