﻿# Sistema Web Farmacia - MVC (UTS)
Proyecto de Trabajo de Grado - Tecnología en Desarrollo de Sistemas Informáticos.

## Instalación Rápida
1. Importa `database/schema.sql` en tu MySQL (phpMyAdmin o consola).
2. Copia el archivo `.env` y ajusta `DB_USER` y `DB_PASS` si es necesario.
3. Inicia tu servidor local (XAMPP/Laragon) apuntando a la carpeta `public/`.
4. Accede a: `http://localhost/farmacia/public/`
5. Usuario: `admin` | Contraseña: `admin123`

## Autores
Jaider Javier Jaimes Picón & Jefferson David Aguilar Rojas
Director: Edgar Alfonso Grimaldos Quintero