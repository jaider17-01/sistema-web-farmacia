<?php
namespace App\Controllers;
use App\Core\Controller;
class DashboardController extends Controller {
    public function index(): string {
        $stats = [
            'total_productos' => (int) $this->db->fetchOne("SELECT COUNT(*) t FROM productos WHERE activo = 1")['t'],
            'ventas_mes' => (float) $this->db->fetchOne("SELECT COALESCE(SUM(total),0) t FROM ventas WHERE MONTH(fecha_venta) = MONTH(CURDATE()) AND YEAR(fecha_venta) = YEAR(CURDATE())")['t'],
        ];
        try { $stats['total_pacientes'] = (int) $this->db->fetchOne("SELECT COUNT(*) t FROM pacientes WHERE activo = 1")['t']; } catch (\Throwable $e) { $stats['total_pacientes'] = 0; }
        try {
            $stock_bajo = $this->db->fetchAll("SELECT p.nombre, p.codigo, p.stock_minimo, COALESCE(SUM(l.cantidad_actual),0) stock FROM productos p LEFT JOIN lotes l ON l.producto_id = p.id WHERE p.activo = 1 GROUP BY p.id HAVING stock <= p.stock_minimo ORDER BY stock ASC LIMIT 6");
        } catch (\Throwable $e) { $stock_bajo = []; }
        $stats['stock_bajo'] = count($stock_bajo);
        try { $ventas_recientes = $this->db->fetchAll("SELECT v.*, COALESCE(p.nombre_completo,'Consumidor Final') paciente FROM ventas v LEFT JOIN pacientes p ON p.id = v.paciente_id ORDER BY v.id DESC LIMIT 6"); } catch (\Throwable $e) { $ventas_recientes = []; }
        $semana = [];
        for ($i = 6; $i >= 0; $i--) $semana[date('Y-m-d', strtotime("-$i day"))] = 0;
        try {
            foreach ($this->db->fetchAll("SELECT DATE(fecha_venta) d, SUM(total) t FROM ventas WHERE fecha_venta >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(fecha_venta)") as $r)
                if (isset($semana[$r['d']])) $semana[$r['d']] = (float) $r['t'];
        } catch (\Throwable $e) {}
        return $this->view('dashboard/index', ['stats' => $stats, 'ventas_recientes' => $ventas_recientes, 'stock_bajo' => $stock_bajo, 'semana' => $semana]);
    }
}