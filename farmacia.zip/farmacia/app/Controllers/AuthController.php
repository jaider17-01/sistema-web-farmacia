<?php
namespace App\Controllers;
use App\Core\Controller;
class AuthController extends Controller {
    public function showLogin(): string {
        if ($this->auth->check()) redirect('/dashboard');
        return $this->view('auth/login');
    }
    public function login(): void {
        $this->validateCsrf();
        if ($this->auth->attempt(trim($this->input('username', '')), $this->input('password', ''))) {
            $this->redirect('/dashboard', ['success' => 'Bienvenido al Sistema']);
        }
        $this->redirect('/login', ['error' => 'Credenciales inválidas']);
    }
    public function logout(): void { $this->auth->logout(); redirect('/login'); }
}