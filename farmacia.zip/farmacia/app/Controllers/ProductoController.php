<?php
namespace App\Controllers;
use App\Core\Controller;
use App\Models\Producto;
use App\Models\Categoria;
class ProductoController extends Controller {
    public function index(): string {
        return $this->view('productos/index', ['productos' => Producto::allWithCategoria()]);
    }
    public function create(): string {
        return $this->view('productos/create', ['categorias' => Categoria::all()]);
    }
    public function store(): void {
        $this->validateCsrf();
        $data = $this->all();
        if (!$this->validator->validate($data, ['codigo' => 'required', 'nombre' => 'required', 'precio_venta' => 'required|numeric', 'stock_minimo' => 'required|numeric'])) {
            $this->redirect('/productos/crear', ['error' => implode(' ', $this->validator->allErrors())]);
        }
        Producto::create([
            'codigo' => trim($data['codigo']), 'nombre' => trim($data['nombre']),
            'categoria_id' => (int) ($data['categoria_id'] ?? 0) ?: null,
            'precio_compra' => (float) ($data['precio_compra'] ?? 0),
            'precio_venta' => (float) $data['precio_venta'],
            'stock_minimo' => (int) $data['stock_minimo'],
            'requiere_formula' => isset($data['requiere_formula']) ? 1 : 0,
        ]);
        $this->redirect('/productos', ['success' => 'Producto creado correctamente']);
    }
    public function edit(string $id): string {
        $producto = Producto::find((int) $id);
        if (!$producto) $this->redirect('/productos', ['error' => 'Producto no encontrado']);
        return $this->view('productos/edit', ['producto' => $producto, 'categorias' => Categoria::all()]);
    }
    public function update(string $id): void {
        $this->validateCsrf();
        $data = $this->all();
        if (!$this->validator->validate($data, ['codigo' => 'required', 'nombre' => 'required', 'precio_venta' => 'required|numeric', 'stock_minimo' => 'required|numeric'])) {
            $this->redirect("/productos/{$id}/editar", ['error' => implode(' ', $this->validator->allErrors())]);
        }
        Producto::updateRecord((int) $id, [
            'codigo' => trim($data['codigo']), 'nombre' => trim($data['nombre']),
            'categoria_id' => (int) ($data['categoria_id'] ?? 0) ?: null,
            'precio_compra' => (float) ($data['precio_compra'] ?? 0),
            'precio_venta' => (float) $data['precio_venta'],
            'stock_minimo' => (int) $data['stock_minimo'],
            'requiere_formula' => isset($data['requiere_formula']) ? 1 : 0,
        ]);
        $this->redirect('/productos', ['success' => 'Producto actualizado correctamente']);
    }
}