<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title ?? 'Farmacia UTS') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f4f6fb;--surface:#fff;--border:#e6eaf2;--text:#0b1526;--muted:#69788c;--primary:#5b5bd6;--primary2:#7c6cf0;--success:#0ea371;--warning:#e8930c;--danger:#e5484d;--radius:18px;--shadow:0 1px 2px rgba(11,21,38,.05),0 12px 32px -16px rgba(11,21,38,.14);--sbw:264px;--font:'Plus Jakarta Sans',system-ui,sans-serif}
body{font-family:var(--font);background:var(--bg);color:var(--text);font-size:14.5px}
.sidebar{position:fixed;inset:0 auto 0 0;width:var(--sbw);background:linear-gradient(180deg,#0e1424,#101a33 60%,#141c3a);color:#c6d0e2;display:flex;flex-direction:column;z-index:40;transition:transform .3s}
.brand{display:flex;gap:12px;align-items:center;padding:22px 20px}
.brand-logo{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,var(--primary),var(--primary2));display:grid;place-items:center;font-size:20px;color:#fff;box-shadow:0 8px 20px -8px rgba(124,108,240,.7)}
.brand b{color:#fff;font-size:15.5px;display:block}.brand small{color:#8fa0bd;font-size:11.5px}
.nav{padding:8px 12px;flex:1;overflow-y:auto}
.nav-label{font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:#67779a;margin:16px 10px 8px}
.nav a{display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;color:#aab8d0;text-decoration:none;font-weight:500;margin-bottom:2px;transition:.2s}
.nav a i{font-size:17px;width:22px;text-align:center}
.nav a:hover{background:rgba(255,255,255,.06);color:#fff}
.nav a.active{background:linear-gradient(90deg,rgba(91,91,214,.28),rgba(124,108,240,.12));color:#fff;box-shadow:inset 0 0 0 1px rgba(124,108,240,.35)}
.nav a.active i{color:#9d8ffa}
.side-foot{padding:16px;border-top:1px solid rgba(255,255,255,.07)}
.main{margin-left:var(--sbw);min-height:100vh;display:flex;flex-direction:column}
.topbar{position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:16px;padding:14px 28px;background:rgba(255,255,255,.8);backdrop-filter:blur(10px);border-bottom:1px solid var(--border)}
.topbar h1{font-size:17px;font-weight:700}.topbar .crumb{color:var(--muted);font-size:12.5px}
.user-chip{margin-left:auto;display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--border);border-radius:999px;padding:6px 14px 6px 6px;box-shadow:var(--shadow)}
.user-chip .ava{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--primary2));color:#fff;display:grid;place-items:center;font-weight:700;font-size:13px}
.user-chip b{font-size:13px;display:block}.user-chip small{color:var(--muted);font-size:11px;display:block}
.content{padding:26px 28px;flex:1}
.grid{display:grid;gap:18px}
.stats{grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin-bottom:18px}
.cols-2{grid-template-columns:2fr 1fr;margin-bottom:18px}
@media(max-width:1100px){.cols-2{grid-template-columns:1fr}}
.card-m{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);animation:rise .45s ease both}
.card-h{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;border-bottom:1px solid var(--border)}
.card-h b{font-size:14.5px}.card-b{padding:20px}
@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.stat{padding:18px 20px;display:flex;gap:14px;align-items:center}
.stat-ic{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;font-size:20px}
.ic-indigo{background:#eceafd;color:#5b5bd6}.ic-green{background:#e2f7ee;color:#0ea371}.ic-amber{background:#fdf1dc;color:#e8930c}.ic-red{background:#fdebec;color:#e5484d}
.stat b{font-size:20px;font-weight:800;display:block;line-height:1.1}.stat small{color:var(--muted);font-size:12px}
.table-m{width:100%;border-collapse:collapse}
.table-m th{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);text-align:left;padding:12px 20px;border-bottom:1px solid var(--border)}
.table-m td{padding:13px 20px;border-bottom:1px solid #eef1f6;vertical-align:middle}
.table-m tr:last-child td{border-bottom:0}
.table-m tbody tr{transition:.15s}.table-m tbody tr:hover{background:#f8f9fd}
.pill{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;font-size:11.5px;font-weight:600}
.pill::before{content:'';width:6px;height:6px;border-radius:50%;background:currentColor}
.pill-ok{background:#e2f7ee;color:#0ea371}.pill-warn{background:#fdf1dc;color:#b26e05}.pill-bad{background:#fdebec;color:#e5484d}.pill-mut{background:#eef1f6;color:#69788c}
.btn{display:inline-flex;align-items:center;gap:8px;border:0;border-radius:12px;padding:10px 16px;font-weight:600;font-size:13.5px;cursor:pointer;text-decoration:none;transition:.2s;font-family:var(--font)}
.btn-primary{background:linear-gradient(135deg,var(--primary),var(--primary2));color:#fff;box-shadow:0 10px 20px -10px rgba(91,91,214,.6)}
.btn-primary:hover{transform:translateY(-1px)}
.btn-ghost{background:#fff;border:1px solid var(--border);color:var(--text)}
.btn-ghost:hover{background:#f6f8fc}
.icon-btn{width:34px;height:34px;display:inline-grid;place-items:center;border-radius:10px;border:1px solid var(--border);background:#fff;color:var(--muted);text-decoration:none;transition:.15s}
.icon-btn:hover{color:var(--primary);border-color:var(--primary);background:#f4f4fe}
.field{margin-bottom:16px}
.field label{display:block;font-size:12.5px;font-weight:600;color:#3c4c63;margin-bottom:6px}
.input{width:100%;border:1px solid var(--border);border-radius:12px;padding:11px 14px;font-family:var(--font);font-size:14px;background:#fbfcfe;transition:.15s;color:var(--text)}
.input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 4px rgba(91,91,214,.12);background:#fff}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 18px}
@media(max-width:800px){.form-grid{grid-template-columns:1fr}}
.check{display:flex!important;align-items:center;gap:8px;font-weight:500!important}
.alert-m{display:flex;gap:10px;align-items:center;border-radius:14px;padding:12px 16px;margin-bottom:18px;font-weight:600;font-size:13.5px;animation:rise .4s ease both}
.alert-ok{background:#e2f7ee;color:#0b7a55;border:1px solid #bfe9d8}
.alert-err{background:#fdebec;color:#c22f34;border:1px solid #f6c9cb}
.toolbar{display:flex;justify-content:space-between;gap:14px;align-items:center;margin-bottom:18px;flex-wrap:wrap}
.search{position:relative}.search i{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted)}
.search .input{padding-left:38px;width:280px}
.empty{padding:40px;text-align:center;color:var(--muted)}
@media(max-width:900px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:none}.main{margin-left:0}}
</style>
</head>
<body>
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-logo"><i class="bi bi-capsule"></i></div>
        <div><b>Farmacia UTS</b><small>Sistema de Gestión v2.0</small></div>
    </div>
    <nav class="nav">
        <div class="nav-label">Principal</div>
        <a href="<?= url('/dashboard') ?>" class="<?= is_active('/dashboard') ?>"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
        <a href="<?= url('/productos') ?>" class="<?= is_active('/productos') ?>"><i class="bi bi-box-seam"></i> Productos</a>
    </nav>
    <div class="side-foot">
        <a href="<?= url('/logout') ?>" class="btn btn-ghost" style="width:100%;justify-content:center"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>
    </div>
</aside>
<div class="main">
    <header class="topbar">
        <button class="icon-btn" onclick="document.getElementById('sidebar').classList.toggle('open')" style="display:none" id="menuBtn"><i class="bi bi-list"></i></button>
        <div><div class="crumb">Inicio / <?= e($title ?? '') ?></div><h1><?= e($title ?? 'Panel') ?></h1></div>
        <?php $n = explode(' ', trim($current_user['nombre_completo'] ?? 'Usuario')); $ini = strtoupper(substr($n[0] ?? 'U', 0, 1) . substr($n[1] ?? $n[0] ?? 'U', 0, 1)); ?>
        <div class="user-chip"><span class="ava"><?= e($ini) ?></span><div><b><?= e($current_user['nombre_completo'] ?? '') ?></b><small><?= e($current_user['rol_nombre'] ?? '') ?></small></div></div>
    </header>
    <main class="content">
        <?php if ($msg = get_flash('success')): ?><div class="alert-m alert-ok"><i class="bi bi-check-circle-fill"></i> <?= e($msg) ?></div><?php endif; ?>
        <?php if ($msg = get_flash('error')): ?><div class="alert-m alert-err"><i class="bi bi-exclamation-triangle-fill"></i> <?= e($msg) ?></div><?php endif; ?>
        <?= $content ?? '' ?>
    </main>
</div>
<script>if(innerWidth<=900)document.getElementById('menuBtn').style.display='inline-grid'</script>
</body>
</html>