<?php $title = 'Productos'; ob_start(); ?>
<div class="toolbar">
    <div class="search"><i class="bi bi-search"></i><input class="input" id="q" placeholder="Buscar producto o código..."></div>
    <a href="<?= url('/productos/crear') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nuevo producto</a>
</div>
<div class="card-m">
    <table class="table-m" id="tbl">
        <thead><tr><th>Código</th><th>Producto</th><th>Categoría</th><th>Stock</th><th>Precio venta</th><th>Fórmula</th><th style="text-align:right">Acciones</th></tr></thead>
        <tbody>
        <?php foreach ($productos as $p): ?>
            <tr>
                <td><code><?= e($p['codigo']) ?></code></td>
                <td><b><?= e($p['nombre']) ?></b></td>
                <td style="color:var(--muted)"><?= e($p['categoria_nombre'] ?? 'Sin categoría') ?></td>
                <td><?php if ((int)$p['stock_total'] <= 0): ?><span class="pill pill-bad">Agotado</span><?php elseif ((int)$p['stock_total'] <= (int)$p['stock_minimo']): ?><span class="pill pill-warn"><?= (int)$p['stock_total'] ?> und</span><?php else: ?><span class="pill pill-ok"><?= (int)$p['stock_total'] ?> und</span><?php endif; ?></td>
                <td><b><?= format_currency($p['precio_venta']) ?></b></td>
                <td><?= $p['requiere_formula'] ? '<span class="pill pill-mut">Requiere</span>' : '<span class="pill pill-mut">No</span>' ?></td>
                <td style="text-align:right"><a class="icon-btn" href="<?= url('/productos/' . $p['id'] . '/editar') ?>" title="Editar"><i class="bi bi-pencil"></i></a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script>
document.getElementById('q').addEventListener('input',function(){var t=this.value.toLowerCase();document.querySelectorAll('#tbl tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(t)?'':'none'})});
</script>
<?php $content = ob_get_clean(); require BASE_PATH . '/app/Views/layouts/app.php'; ?>