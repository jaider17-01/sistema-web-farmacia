<div class="card-m">
    <div class="card-h"><b><?= $producto ? 'Editar producto' : 'Registrar nuevo producto' ?></b></div>
    <div class="card-b">
        <form method="POST" action="<?= $producto ? url('/productos/' . $producto['id']) : url('/productos') ?>">
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field"><label>Código *</label><input class="input" name="codigo" required value="<?= e($producto['codigo'] ?? '') ?>" placeholder="ACET-500"></div>
                <div class="field"><label>Nombre *</label><input class="input" name="nombre" required value="<?= e($producto['nombre'] ?? '') ?>" placeholder="Acetaminofén 500mg"></div>
                <div class="field"><label>Categoría</label><select class="input" name="categoria_id"><option value="">Sin categoría</option><?php foreach ($categorias as $c): ?><option value="<?= $c['id'] ?>" <?= ($producto['categoria_id'] ?? null) == $c['id'] ? 'selected' : '' ?>><?= e($c['nombre']) ?></option><?php endforeach; ?></select></div>
                <div class="field"><label>Stock mínimo *</label><input type="number" min="0" class="input" name="stock_minimo" required value="<?= e($producto['stock_minimo'] ?? '10') ?>"></div>
                <div class="field"><label>Precio de compra</label><input type="number" step="0.01" min="0" class="input" name="precio_compra" value="<?= e($producto['precio_compra'] ?? '0') ?>"></div>
                <div class="field"><label>Precio de venta *</label><input type="number" step="0.01" min="0" class="input" name="precio_venta" required value="<?= e($producto['precio_venta'] ?? '') ?>"></div>
            </div>
            <div class="field"><label class="check"><input type="checkbox" name="requiere_formula" <?= ($producto['requiere_formula'] ?? 0) ? 'checked' : '' ?>> Requiere fórmula médica</label></div>
            <div style="display:flex;gap:10px">
                <button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Guardar</button>
                <a class="btn btn-ghost" href="<?= url('/productos') ?>">Cancelar</a>
            </div>
        </form>
    </div>
</div>