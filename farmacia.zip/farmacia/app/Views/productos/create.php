<?php $title = 'Nuevo producto'; $producto = null; ob_start(); ?>
<?php include __DIR__ . '/form.php'; ?>
<?php $content = ob_get_clean(); require BASE_PATH . '/app/Views/layouts/app.php'; ?>