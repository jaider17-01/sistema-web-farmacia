<?php $title = 'Dashboard'; ob_start(); ?>
<div class="grid stats">
    <div class="card-m stat"><div class="stat-ic ic-indigo"><i class="bi bi-box-seam"></i></div><div><b><?= (int) $stats['total_productos'] ?></b><small>Productos activos</small></div></div>
    <div class="card-m stat"><div class="stat-ic ic-green"><i class="bi bi-cash-stack"></i></div><div><b><?= format_currency($stats['ventas_mes']) ?></b><small>Ventas del mes</small></div></div>
    <div class="card-m stat"><div class="stat-ic ic-amber"><i class="bi bi-people"></i></div><div><b><?= (int) $stats['total_pacientes'] ?></b><small>Pacientes</small></div></div>
    <div class="card-m stat"><div class="stat-ic ic-red"><i class="bi bi-exclamation-triangle"></i></div><div><b><?= (int) $stats['stock_bajo'] ?></b><small>Alertas de stock</small></div></div>
</div>
<div class="grid cols-2">
    <div class="card-m">
        <div class="card-h"><b><i class="bi bi-graph-up"></i> Ventas últimos 7 días</b></div>
        <div class="card-b" style="height:280px"><canvas id="chartVentas"></canvas></div>
    </div>
    <div class="card-m">
        <div class="card-h"><b><i class="bi bi-clipboard-x"></i> Stock bajo</b></div>
        <?php if (empty($stock_bajo)): ?><div class="empty"><i class="bi bi-check2-circle"></i> Sin alertas de inventario</div>
        <?php else: ?>
        <table class="table-m"><tbody>
        <?php foreach ($stock_bajo as $s): ?>
            <tr><td><b><?= e($s['nombre']) ?></b><br><small style="color:var(--muted)"><?= e($s['codigo']) ?></small></td>
            <td style="text-align:right"><span class="pill pill-bad"><?= (int) $s['stock'] ?> und</span></td></tr>
        <?php endforeach; ?>
        </tbody></table><?php endif; ?>
    </div>
</div>
<div class="card-m">
    <div class="card-h"><b><i class="bi bi-clock-history"></i> Últimas ventas</b></div>
    <?php if (empty($ventas_recientes)): ?><div class="empty">Aún no hay ventas registradas</div>
    <?php else: ?>
    <table class="table-m">
        <thead><tr><th>Número</th><th>Paciente</th><th>Fecha</th><th style="text-align:right">Total</th></tr></thead>
        <tbody>
        <?php foreach ($ventas_recientes as $v): ?>
            <tr><td><code><?= e($v['numero_venta']) ?></code></td><td><?= e($v['paciente']) ?></td><td style="color:var(--muted)"><?= date('d/m/Y H:i', strtotime($v['fecha_venta'])) ?></td><td style="text-align:right"><b><?= format_currency($v['total']) ?></b></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table><?php endif; ?>
</div>
<script>
var ctx=document.getElementById('chartVentas');
if(ctx&&window.Chart){new Chart(ctx,{type:'line',data:{labels:<?= json_encode(array_map(function($d){return date('d/m',strtotime($d));}, array_keys($semana))) ?>,datasets:[{data:<?= json_encode(array_values($semana)) ?>,borderColor:'#5b5bd6',backgroundColor:'rgba(91,91,214,.12)',fill:true,tension:.4,pointRadius:3,pointBackgroundColor:'#5b5bd6',borderWidth:2}]},options:{plugins:{legend:{display:false}},scales:{y:{ticks:{callback:function(v){return '$'+Number(v).toLocaleString('es-CO')}}}},maintainAspectRatio:false}});}
</script>
<?php $content = ob_get_clean(); require BASE_PATH . '/app/Views/layouts/app.php'; ?>