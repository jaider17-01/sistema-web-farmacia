<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Iniciar Sesión - Farmacia UTS</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css" rel="stylesheet">
<style>
*{margin:0;box-sizing:border-box}
body{font-family:'Plus Jakarta Sans',system-ui,sans-serif;background:#eef1f8;min-height:100vh;display:grid;place-items:center;padding:20px}
.wrap{display:grid;grid-template-columns:1.05fr 1fr;width:min(960px,94vw);min-height:580px;border-radius:26px;overflow:hidden;box-shadow:0 40px 90px -35px rgba(11,21,38,.4);background:#fff;animation:pop .5s ease both}
@keyframes pop{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.panel{background:linear-gradient(150deg,#4f46e5,#7c6cf0 55%,#9d8ffa);color:#fff;padding:46px;display:flex;flex-direction:column;position:relative;overflow:hidden}
.panel::before,.panel::after{content:'';position:absolute;border-radius:50%;background:rgba(255,255,255,.1)}
.panel::before{width:340px;height:340px;top:-120px;right:-120px}
.panel::after{width:220px;height:220px;bottom:-80px;left:-60px}
.logo{width:52px;height:52px;border-radius:16px;background:rgba(255,255,255,.18);backdrop-filter:blur(6px);display:grid;place-items:center;font-size:24px;margin-bottom:28px}
.panel h1{font-size:28px;font-weight:800;line-height:1.2;margin-bottom:12px}
.panel p{color:rgba(255,255,255,.85);font-size:14px;line-height:1.6;max-width:340px}
.feats{margin-top:auto;display:grid;gap:12px}
.feat{display:flex;gap:10px;align-items:center;font-size:13px;font-weight:600}
.feat i{width:30px;height:30px;border-radius:10px;background:rgba(255,255,255,.16);display:grid;place-items:center}
.form-side{padding:46px;display:flex;flex-direction:column;justify-content:center}
.form-side h2{font-size:22px;font-weight:800;color:#0b1526}
.form-side .sub{color:#69788c;font-size:13.5px;margin:6px 0 28px}
.field{margin-bottom:18px}
.field label{display:block;font-size:12.5px;font-weight:600;color:#3c4c63;margin-bottom:6px}
.input-wrap{position:relative}
.input-wrap i.lead{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#9aa7bb}
.input{width:100%;border:1px solid #e6eaf2;border-radius:13px;padding:12px 44px 12px 42px;font-family:inherit;font-size:14px;background:#fbfcfe;transition:.15s}
.input:focus{outline:none;border-color:#5b5bd6;box-shadow:0 0 0 4px rgba(91,91,214,.12);background:#fff}
.eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);border:0;background:none;color:#9aa7bb;cursor:pointer;padding:6px}
.btn{width:100%;border:0;border-radius:13px;padding:13px;background:linear-gradient(135deg,#5b5bd6,#7c6cf0);color:#fff;font-weight:700;font-size:14.5px;cursor:pointer;font-family:inherit;box-shadow:0 14px 28px -12px rgba(91,91,214,.65);transition:.2s}
.btn:hover{transform:translateY(-1px)}
.alert{border-radius:13px;padding:11px 14px;margin-bottom:16px;font-size:13px;font-weight:600;background:#fdebec;color:#c22f34;border:1px solid #f6c9cb}
.foot{margin-top:22px;text-align:center;color:#9aa7bb;font-size:11.5px}
@media(max-width:820px){.wrap{grid-template-columns:1fr}.panel{display:none}}
</style>
</head>
<body>
<div class="wrap">
    <div class="panel">
        <div class="logo"><i class="bi bi-capsule"></i></div>
        <h1>Gestión farmacéutica inteligente</h1>
        <p>Plataforma integral para el control de inventarios, compras, ventas y fórmulas médicas con trazabilidad completa.</p>
        <div class="feats">
            <div class="feat"><i class="bi bi-shield-check"></i> Seguridad y cifrado BCrypt</div>
            <div class="feat"><i class="bi bi-boxes"></i> Inventario con control de lotes</div>
            <div class="feat"><i class="bi bi-file-medical"></i> Fórmulas médicas verificables</div>
        </div>
    </div>
    <div class="form-side">
        <h2>Bienvenido de nuevo</h2>
        <div class="sub">Ingresa tus credenciales para continuar</div>
        <?php if ($msg = get_flash('error')): ?><div class="alert"><?= e($msg) ?></div><?php endif; ?>
        <form method="POST" action="<?= url('/login') ?>">
            <?= csrf_field() ?>
            <div class="field">
                <label>Usuario</label>
                <div class="input-wrap"><i class="bi bi-person lead"></i>
                    <input class="input" type="text" name="username" placeholder="tu.usuario" required autofocus>
                </div>
            </div>
            <div class="field">
                <label>Contraseña</label>
                <div class="input-wrap"><i class="bi bi-lock lead"></i>
                    <input class="input" type="password" name="password" id="pass" placeholder="••••••••" required>
                    <button type="button" class="eye" onclick="var p=document.getElementById('pass');p.type=p.type==='password'?'text':'password'"><i class="bi bi-eye"></i></button>
                </div>
            </div>
            <button class="btn" type="submit">Iniciar sesión <i class="bi bi-arrow-right"></i></button>
        </form>
        <div class="foot">Trabajo de Grado UTS — <?= date('Y') ?></div>
    </div>
</div>
</body>
</html>