<?php
namespace App\Models;
use App\Core\Model;
class Usuario extends Model {
    protected static string $table = 'usuarios';
    protected static array $fillable = ['username', 'password', 'nombre_completo', 'email', 'rol_id', 'activo'];
    public static function findByUsername(string $username): ?array {
        return \App\Core\Database::getInstance()->fetchOne("SELECT u.*, r.nombre as rol_nombre FROM usuarios u INNER JOIN roles r ON u.rol_id = r.id WHERE u.username = ?", [$username]);
    }
    public static function createUser(array $data): int {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
        return self::create($data);
    }
}