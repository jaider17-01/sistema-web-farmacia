<?php
namespace App\Models;
use App\Core\Model;
class Producto extends Model {
    protected static string $table = 'productos';
    protected static array $fillable = ['codigo', 'nombre', 'descripcion', 'categoria_id', 'principio_activo', 'presentacion', 'precio_compra', 'precio_venta', 'stock_minimo', 'requiere_formula', 'posicion', 'activo'];
    public static function allWithCategoria(): array {
        return \App\Core\Database::getInstance()->fetchAll(
            "SELECT p.*, c.nombre as categoria_nombre, COALESCE(SUM(l.cantidad_actual),0) as stock_total
             FROM productos p
             LEFT JOIN categorias c ON p.categoria_id = c.id
             LEFT JOIN lotes l ON l.producto_id = p.id
             GROUP BY p.id ORDER BY p.id DESC"
        );
    }
}