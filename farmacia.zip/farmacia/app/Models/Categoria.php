<?php
namespace App\Models;
use App\Core\Model;
class Categoria extends Model {
    protected static string $table = 'categorias';
    protected static array $fillable = ['nombre', 'descripcion', 'activo'];
}