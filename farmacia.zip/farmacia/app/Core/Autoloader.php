<?php
namespace App\Core;

class Autoloader {
    private static array $namespaces = [
        'App\\' => '/app/'
    ];

    public static function register(): void {
        spl_autoload_register([__CLASS__, 'load']);
    }

    public static function load(string $class): void {
        foreach (self::$namespaces as $namespace => $baseDir) {
            if (strpos($class, $namespace) === 0) {
                $relativeClass = substr($class, strlen($namespace));
                $file = BASE_PATH . $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
                if (file_exists($file)) {
                    require_once $file;
                    return;
                }
            }
        }
    }
}