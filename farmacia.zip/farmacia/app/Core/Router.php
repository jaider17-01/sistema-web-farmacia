<?php
namespace App\Core;
class Router {
    private array $routes = [];
    private Auth $auth;
    public function __construct(Auth $auth) { $this->auth = $auth; }
    public function get(string $uri, string $controller, string $method, array $options = []): void { $this->addRoute('GET', $uri, $controller, $method, $options); }
    public function post(string $uri, string $controller, string $method, array $options = []): void { $this->addRoute('POST', $uri, $controller, $method, $options); }
    private function addRoute(string $method, string $uri, string $controller, string $methodAction, array $options): void {
        $this->routes[$method][] = [
            'uri' => $uri, 'controller' => $controller, 'method' => $methodAction,
            'auth' => $options['auth'] ?? false, 'roles' => $options['roles'] ?? null,
            'pattern' => '#^' . preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[0-9a-zA-Z_-]+)', $uri) . '$#'
        ];
    }
    public function resolve(string $method, string $uri): ?array {
        foreach ($this->routes[$method] ?? [] as $route) {
            if (preg_match($route['pattern'], $uri, $matches)) {
                return ['controller' => $route['controller'], 'method' => $route['method'], 'auth' => $route['auth'], 'roles' => $route['roles'], 'params' => array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY)];
            }
        }
        return null;
    }
}