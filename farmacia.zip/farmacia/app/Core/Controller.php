<?php
namespace App\Core;
abstract class Controller {
    protected Database $db; protected Session $session; protected Auth $auth; protected Validator $validator;
    public function __construct() {
        $app = Application::getInstance();
        $this->db = $app->getService('db'); $this->session = $app->getService('session');
        $this->auth = $app->getService('auth'); $this->validator = $app->getService('validator');
    }
    protected function view(string $view, array $data = []): string {
        $data['auth'] = $this->auth; $data['session'] = $this->session; $data['current_user'] = $this->auth->user();
        $data['csrf_token'] = $this->session->get('csrf_token');
        return View::render($view, $data, true);
    }
    protected function redirect(string $url, array $flash = []): void {
        foreach ($flash as $key => $value) $this->session->setFlash($key, $value);
        header("Location: {$url}"); exit;
    }
    protected function input(string $key, $default = null) { return $_POST[$key] ?? $_GET[$key] ?? $default; }
    protected function validateCsrf(): bool {
        $token = $_POST['_token'] ?? ''; $expected = $this->session->get('csrf_token');
        if (empty($token) || empty($expected) || !hash_equals($expected, $token)) { http_response_code(403); exit('Token CSRF inválido'); }
        return true;
    }
}