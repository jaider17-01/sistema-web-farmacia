<?php
namespace App\Core;
class ErrorHandler {
    public static function handle(\Throwable $e): void {
        $isProd = (getenv('APP_ENV') ?? 'production') === 'production';
        if ($isProd) { http_response_code(500); echo "<h1>Error del servidor</h1>"; } 
        else { http_response_code(500); echo "<h1>Error: " . htmlspecialchars($e->getMessage()) . "</h1><pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>"; }
        exit;
    }
}