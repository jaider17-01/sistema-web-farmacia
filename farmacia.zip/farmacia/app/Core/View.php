<?php
namespace App\Core;
class View {
    public static function render(string $view, array $data = [], bool $return = false): string {
        $viewFile = BASE_PATH . "/app/Views/{$view}.php";
        if (!file_exists($viewFile)) throw new \RuntimeException("Vista no encontrada: {$view}");
        extract($data);
        ob_start(); require $viewFile; $content = ob_get_clean();
        return $return ? $content : ($content ?: '');
    }
}