<?php
namespace App\Core;
use PDO;
class Database {
    private static ?Database $instance = null;
    private PDO $connection;
    private function __construct() {
        $dsn = "mysql:host=" . (getenv('DB_HOST') ?: 'localhost') . ";dbname=" . (getenv('DB_NAME') ?: 'farmacia') . ";charset=" . (getenv('DB_CHARSET') ?: 'utf8mb4');
        $this->connection = new PDO($dsn, getenv('DB_USER') ?: 'root', getenv('DB_PASS') ?: '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
    }
    public static function getInstance(): self {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }
    public function query(string $sql, array $params = []): \PDOStatement {
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    public function fetchOne(string $sql, array $params = []): ?array {
        $result = $this->query($sql, $params)->fetch();
        return $result ?: null;
    }
    public function fetchAll(string $sql, array $params = []): array {
        return $this->query($sql, $params)->fetchAll();
    }
    public function insert(string $table, array $data): int {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $this->query("INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})", array_values($data));
        return (int) $this->connection->lastInsertId();
    }
    public function update(string $table, array $data, string $where, array $whereParams = []): int {
        $set = implode(', ', array_map(fn($c) => "{$c} = ?", array_keys($data)));
        return $this->query("UPDATE {$table} SET {$set} WHERE {$where}", array_merge(array_values($data), $whereParams))->rowCount();
    }
    public function delete(string $table, string $where, array $params = []): int {
        return $this->query("DELETE FROM {$table} WHERE {$where}", $params)->rowCount();
    }
    public function transaction(callable $cb) {
        $this->connection->beginTransaction();
        try { $r = $cb($this); $this->connection->commit(); return $r; }
        catch (\Throwable $e) { $this->connection->rollBack(); throw $e; }
    }
}