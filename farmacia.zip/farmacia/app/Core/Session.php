<?php
namespace App\Core;
class Session {
    public function get(string $key, $default = null) { return $_SESSION[$key] ?? $default; }
    public function set(string $key, $value): void { $_SESSION[$key] = $value; }
    public function has(string $key): bool { return isset($_SESSION[$key]); }
    public function setFlash(string $key, $value): void { $_SESSION['_flash'][$key] = $value; }
    public function getFlash(string $key, $default = null) {
        $value = $_SESSION['_flash'][$key] ?? $default; unset($_SESSION['_flash'][$key]); return $value;
    }
    public function regenerate(): void { session_regenerate_id(true); }
    public function destroy(): void { session_destroy(); $_SESSION = []; }
}