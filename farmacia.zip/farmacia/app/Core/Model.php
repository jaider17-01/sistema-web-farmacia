<?php
namespace App\Core;
abstract class Model {
    protected static string $table = ''; protected static array $fillable = [];
    public static function all(string $orderBy = 'id DESC'): array {
        return Database::getInstance()->fetchAll("SELECT * FROM " . static::$table . " ORDER BY {$orderBy}");
    }
    public static function find(int $id): ?array {
        return Database::getInstance()->fetchOne("SELECT * FROM " . static::$table . " WHERE id = ?", [$id]);
    }
    public static function create(array $data): int {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        return Database::getInstance()->insert(static::$table, $filtered);
    }
}