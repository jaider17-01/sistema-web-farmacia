<?php
namespace App\Core;
class Validator {
    private array $errors = [];
    public function validate(array $data, array $rules): bool {
        $this->errors = [];
        foreach ($rules as $field => $ruleSet) {
            $value = $data[$field] ?? null;
            $label = ucwords(str_replace('_', ' ', $field));
            foreach (explode('|', $ruleSet) as $rule) {
                if ($rule === 'required' && ($value === null || $value === '')) $this->errors[$field][] = "El campo {$label} es obligatorio";
                elseif ($rule === 'numeric' && $value !== null && $value !== '' && !is_numeric($value)) $this->errors[$field][] = "{$label} debe ser numérico";
                elseif ($rule === 'email' && $value && !filter_var($value, FILTER_VALIDATE_EMAIL)) $this->errors[$field][] = "{$label} debe ser un email válido";
                elseif (strpos($rule, 'min:') === 0 && strlen((string) $value) < (int) substr($rule, 4)) $this->errors[$field][] = "{$label} requiere mínimo " . substr($rule, 4) . " caracteres";
            }
        }
        return empty($this->errors);
    }
    public function errors(): array { return $this->errors; }
    public function allErrors(): array {
        $out = [];
        foreach ($this->errors as $msgs) foreach ($msgs as $m) $out[] = $m;
        return $out;
    }
}