<?php
namespace App\Core;
class Auth {
    private Database $db; private Session $session;
    public function __construct(Database $db, Session $session) { $this->db = $db; $this->session = $session; }
    public function attempt(string $username, string $password): bool {
        $user = $this->db->fetchOne("SELECT u.*, r.nombre as rol_nombre FROM usuarios u INNER JOIN roles r ON u.rol_id = r.id WHERE u.username = ? AND u.activo = 1", [$username]);
        if (!$user || !password_verify($password, $user['password'])) return false;
        $this->session->regenerate();
        unset($user['password']);
        $this->session->set('user', $user); $this->session->set('user_id', $user['id']); $this->session->set('user_role', $user['rol_nombre']);
        return true;
    }
    public function check(): bool { return $this->session->has('user'); }
    public function user(): ?array { return $this->session->get('user'); }
    public function hasRole(string $role): bool { return $this->session->get('user_role') === $role; }
    public function logout(): void { $this->session->destroy(); session_start(); $this->session->regenerate(); }
}