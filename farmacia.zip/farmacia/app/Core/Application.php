<?php
namespace App\Core;

class Application {
    private static ?Application $instance = null;
    private array $services = [];
    private Router $router;

    public function __construct() {
        self::$instance = $this;
        global $app;
        $app = $this;
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function registerServices(): void {
        $this->services['db'] = Database::getInstance();
        $this->services['session'] = new Session();
        $this->services['auth'] = new Auth($this->services['db'], $this->services['session']);
        $this->services['validator'] = new Validator();
        $this->router = new Router($this->services['auth']);
        require_once BASE_PATH . '/routes/web.php';
    }

    public function getRouter(): Router {
        return $this->router;
    }

    public function getService(string $name) {
        return $this->services[$name] ?? null;
    }

    public function run(): void {
        $method = $_SERVER['REQUEST_METHOD'];
        
        // 1. Detectar la ruta base (ej: /farmacia/public)
        $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // 2. Eliminar la ruta base de la URI para que el Router solo vea "/"
        if ($basePath !== '/' && strpos($uri, $basePath) === 0) {
            $uri = substr($uri, strlen($basePath));
        }
        
        $uri = rtrim($uri, '/') ?: '/';
        
        $route = $this->router->resolve($method, $uri);
        
        if ($route === null) {
            http_response_code(404);
            echo "404 No encontrado - Ruta solicitada: " . htmlspecialchars($uri);
            return;
        }
        
        if ($route['auth'] && !$this->services['auth']->check()) {
            redirect('/login');
            return;
        }
        
        $controller = new $route['controller']();
        $response = call_user_func_array([$controller, $route['method']], $route['params'] ?? []);
        
        if (is_string($response)) {
            echo $response;
        }
    }
}