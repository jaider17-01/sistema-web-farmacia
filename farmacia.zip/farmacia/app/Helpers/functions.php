<?php
function redirect(string $url): void { header("Location: {$url}"); exit; }
function url(string $path = ''): string { return rtrim(getenv('APP_URL') ?: '/', '/') . '/' . ltrim($path, '/'); }
function e(string $value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
function csrf_field(): string { return '<input type="hidden" name="_token" value="' . e($_SESSION['csrf_token'] ?? '') . '">'; }
function format_currency($amount): string { return '$ ' . number_format((float) $amount, 0, ',', '.'); }
function get_flash(string $type): ?string {
    $msg = $_SESSION['_flash'][$type] ?? null;
    unset($_SESSION['_flash'][$type]);
    return $msg;
}
function is_active(string $path): string {
    $base = rtrim((string) parse_url((string) getenv('APP_URL'), PHP_URL_PATH), '/');
    $current = (string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($base !== '' && strpos($current, $base) === 0) $current = substr($current, strlen($base));
    $current = rtrim($current, '/') ?: '/';
    $path = rtrim($path, '/') ?: '/';
    return ($current === $path || ($path !== '/' && strpos($current, $path) === 0)) ? 'active' : '';
}