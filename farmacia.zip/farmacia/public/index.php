<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
define('BASE_PATH', dirname(__DIR__));
define('PUBLIC_PATH', __DIR__);
require_once BASE_PATH . '/config/errors.php';
require_once BASE_PATH . '/app/Core/Autoloader.php';
App\Core\Autoloader::register();
require_once BASE_PATH . '/app/Helpers/functions.php';
require_once BASE_PATH . '/config/session.php';
require_once BASE_PATH . '/config/env.php';
try {
    $app = new App\Core\Application();
    $app->registerServices();
    $app->run();
} catch (\Throwable $e) {
    App\Core\ErrorHandler::handle($e);
}