<?php
global $app;
$router = $app->getRouter();
$router->get('/login', \App\Controllers\AuthController::class, 'showLogin');
$router->post('/login', \App\Controllers\AuthController::class, 'login');
$router->get('/logout', \App\Controllers\AuthController::class, 'logout');
$router->get('/', \App\Controllers\DashboardController::class, 'index', ['auth' => true]);
$router->get('/dashboard', \App\Controllers\DashboardController::class, 'index', ['auth' => true]);
$router->get('/productos', \App\Controllers\ProductoController::class, 'index', ['auth' => true]);
$router->get('/productos/crear', \App\Controllers\ProductoController::class, 'create', ['auth' => true]);
$router->post('/productos', \App\Controllers\ProductoController::class, 'store', ['auth' => true]);
$router->get('/productos/{id}/editar', \App\Controllers\ProductoController::class, 'edit', ['auth' => true]);
$router->post('/productos/{id}', \App\Controllers\ProductoController::class, 'update', ['auth' => true]);