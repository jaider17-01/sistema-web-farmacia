import os

# Estructura completa del proyecto con su contenido
PROJECT_FILES = {
    ".env": """APP_NAME="Sistema Web Farmacia"
APP_ENV=development
APP_DEBUG=true
APP_URL=http://localhost/farmacia/public

DB_HOST=localhost
DB_NAME=farmacia
DB_USER=root
DB_PASS=
DB_CHARSET=utf8mb4

SESSION_LIFETIME=120
SESSION_SECURE=false
PER_PAGE=10""",

    ".gitignore": """.env
storage/logs/*.log
*.log
.DS_Store
Thumbs.db
.vscode/
.idea/
*.zip""",

    "public/index.php": """<?php
declare(strict_types=1);
define('APP_START', microtime(true));
define('BASE_PATH', dirname(__DIR__));
define('PUBLIC_PATH', __DIR__);

require_once BASE_PATH . '/config/errors.php';
require_once BASE_PATH . '/app/Core/Autoloader.php';
App\\Core\\Autoloader::register();
require_once BASE_PATH . '/app/Helpers/functions.php';
require_once BASE_PATH . '/config/session.php';
require_once BASE_PATH . '/config/env.php';

try {
    $app = new App\\Core\\Application();
    $app->registerServices();
    $app->run();
} catch (\\Throwable $e) {
    App\\Core\\ErrorHandler::handle($e);
}""",

    "public/.htaccess": """<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php [QSA,L]
</IfModule>
<FilesMatch "\\.(env|log|md|sql|json)$">
    Order allow,deny
    Deny from all
</FilesMatch>
Options -Indexes""",

    "config/env.php": """<?php
$envFile = BASE_PATH . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value, " \\t\\n\\r\"'"));
        }
    }
}""",

    "config/errors.php": """<?php
$isDebug = (getenv('APP_DEBUG') ?? 'false') === 'true';
if ($isDebug) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}
ini_set('log_errors', '1');""",

    "config/session.php": """<?php
ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_samesite', 'Lax');
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}""",

    "app/Helpers/functions.php": """<?php
function redirect(string $url): void { header("Location: {$url}"); exit; }
function asset(string $path): string { return rtrim(getenv('APP_URL') ?: '/', '/') . '/' . ltrim($path, '/'); }
function url(string $path = ''): string { return rtrim(getenv('APP_URL') ?: '/', '/') . '/' . ltrim($path, '/'); }
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function csrf_field(): string { return '<input type="hidden" name="_token" value="' . e($_SESSION['csrf_token'] ?? '') . '">'; }
function format_currency($amount): string { return '$' . number_format((float) $amount, 0, ',', '.'); }
function format_datetime(?string $datetime): string { return $datetime ? date('d/m/Y H:i', strtotime($datetime)) : ''; }
function is_active(string $path): string {
    $current = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    return $current === $path || strpos($current, $path) === 0 ? 'active' : '';
}
function get_flash(string $type): ?string {
    $msg = $_SESSION['_flash'][$type] ?? null;
    unset($_SESSION['_flash'][$type]);
    return $msg;
}""",

    "app/Core/Autoloader.php": """<?php
namespace App\\Core;
class Autoloader {
    private static array $namespaces = ['App\\\\' => '/app/'];
    public static function register(): void { spl_autoload_register([self::class, 'load']); }
    public static function load(string $class): void {
        foreach (self::$namespaces as $namespace => $baseDir) {
            if (strpos($class, $namespace) === 0) {
                $file = BASE_PATH . $baseDir . str_replace('\\\\', '/', substr($class, strlen($namespace))) . '.php';
                if (file_exists($file)) { require_once $file; return; }
            }
        }
    }
}""",

    "app/Core/Database.php": """<?php
namespace App\\Core;
use PDO;
class Database {
    private static ?Database $instance = null;
    private PDO $connection;
    private function __construct() {
        $dsn = "mysql:host=" . (getenv('DB_HOST')?:'localhost') . ";dbname=" . (getenv('DB_NAME')?:'farmacia') . ";charset=" . (getenv('DB_CHARSET')?:'utf8mb4');
        $this->connection = new PDO($dsn, getenv('DB_USER')?:'root', getenv('DB_PASS')?:'', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
    }
    public static function getInstance(): self {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }
    public function query(string $sql, array $params = []): \\PDOStatement {
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    public function fetchOne(string $sql, array $params = []): ?array {
        $result = $this->query($sql, $params)->fetch();
        return $result ?: null;
    }
    public function fetchAll(string $sql, array $params = []): array {
        return $this->query($sql, $params)->fetchAll();
    }
    public function insert(string $table, array $data): int {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $this->query("INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})", array_values($data));
        return (int) $this->connection->lastInsertId();
    }
    public function transaction(callable $callback) {
        $this->connection->beginTransaction();
        try { $result = $callback($this); $this->connection->commit(); return $result; } 
        catch (\\Throwable $e) { $this->connection->rollBack(); throw $e; }
    }
}""",

    "app/Core/Router.php": """<?php
namespace App\\Core;
class Router {
    private array $routes = [];
    private Auth $auth;
    public function __construct(Auth $auth) { $this->auth = $auth; }
    public function get(string $uri, string $controller, string $method, array $options = []): void { $this->addRoute('GET', $uri, $controller, $method, $options); }
    public function post(string $uri, string $controller, string $method, array $options = []): void { $this->addRoute('POST', $uri, $controller, $method, $options); }
    private function addRoute(string $method, string $uri, string $controller, string $methodAction, array $options): void {
        $this->routes[$method][] = [
            'uri' => $uri, 'controller' => $controller, 'method' => $methodAction,
            'auth' => $options['auth'] ?? false, 'roles' => $options['roles'] ?? null,
            'pattern' => '#^' . preg_replace('/\\{([a-zA-Z_]+)\\}/', '(?P<$1>[0-9a-zA-Z_-]+)', $uri) . '$#'
        ];
    }
    public function resolve(string $method, string $uri): ?array {
        foreach ($this->routes[$method] ?? [] as $route) {
            if (preg_match($route['pattern'], $uri, $matches)) {
                return ['controller' => $route['controller'], 'method' => $route['method'], 'auth' => $route['auth'], 'roles' => $route['roles'], 'params' => array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY)];
            }
        }
        return null;
    }
}""",

    "app/Core/Controller.php": """<?php
namespace App\\Core;
abstract class Controller {
    protected Database $db; protected Session $session; protected Auth $auth; protected Validator $validator;
    public function __construct() {
        $app = Application::getInstance();
        $this->db = $app->getService('db'); $this->session = $app->getService('session');
        $this->auth = $app->getService('auth'); $this->validator = $app->getService('validator');
    }
    protected function view(string $view, array $data = []): string {
        $data['auth'] = $this->auth; $data['session'] = $this->session; $data['current_user'] = $this->auth->user();
        $data['csrf_token'] = $this->session->get('csrf_token');
        return View::render($view, $data, true);
    }
    protected function redirect(string $url, array $flash = []): void {
        foreach ($flash as $key => $value) $this->session->setFlash($key, $value);
        header("Location: {$url}"); exit;
    }
    protected function input(string $key, $default = null) { return $_POST[$key] ?? $_GET[$key] ?? $default; }
    protected function all(): array { return array_merge($_GET, $_POST); }
    protected function validateCsrf(): bool {
        $token = $_POST['_token'] ?? ''; $expected = $this->session->get('csrf_token');
        if (empty($token) || empty($expected) || !hash_equals($expected, $token)) { http_response_code(403); exit('Token CSRF inválido'); }
        return true;
    }
}""",

    "app/Core/Model.php": """<?php
namespace App\\Core;
abstract class Model {
    protected static string $table = ''; protected static array $fillable = [];
    public static function all(string $orderBy = 'id DESC'): array {
        return Database::getInstance()->fetchAll("SELECT * FROM " . static::$table . " ORDER BY {$orderBy}");
    }
    public static function find(int $id): ?array {
        return Database::getInstance()->fetchOne("SELECT * FROM " . static::$table . " WHERE id = ?", [$id]);
    }
    public static function create(array $data): int {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        return Database::getInstance()->insert(static::$table, $filtered);
    }
    public static function updateRecord(int $id, array $data): int {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        $set = implode(', ', array_map(fn($col) => "{$col} = ?", array_keys($filtered)));
        $params = array_merge(array_values($filtered), [$id]);
        return Database::getInstance()->query("UPDATE " . static::$table . " SET {$set} WHERE id = ?", $params)->rowCount();
    }
}""",

    "app/Core/View.php": """<?php
namespace App\\Core;
class View {
    public static function render(string $view, array $data = [], bool $return = false): string {
        $viewFile = BASE_PATH . "/app/Views/{$view}.php";
        if (!file_exists($viewFile)) throw new \\RuntimeException("Vista no encontrada: {$view}");
        extract($data);
        ob_start(); require $viewFile; $content = ob_get_clean();
        return $return ? $content : ($content ?: '');
    }
}""",

    "app/Core/Session.php": """<?php
namespace App\\Core;
class Session {
    public function get(string $key, $default = null) { return $_SESSION[$key] ?? $default; }
    public function set(string $key, $value): void { $_SESSION[$key] = $value; }
    public function has(string $key): bool { return isset($_SESSION[$key]); }
    public function setFlash(string $key, $value): void { $_SESSION['_flash'][$key] = $value; }
    public function getFlash(string $key, $default = null) {
        $value = $_SESSION['_flash'][$key] ?? $default; unset($_SESSION['_flash'][$key]); return $value;
    }
    public function regenerate(): void { session_regenerate_id(true); }
    public function destroy(): void { session_destroy(); $_SESSION = []; }
}""",

    "app/Core/Auth.php": """<?php
namespace App\\Core;
class Auth {
    private Database $db; private Session $session;
    public function __construct(Database $db, Session $session) { $this->db = $db; $this->session = $session; }
    public function attempt(string $username, string $password): bool {
        $user = $this->db->fetchOne("SELECT u.*, r.nombre as rol_nombre FROM usuarios u INNER JOIN roles r ON u.rol_id = r.id WHERE u.username = ? AND u.activo = 1", [$username]);
        if (!$user || !password_verify($password, $user['password'])) return false;
        $this->session->regenerate();
        unset($user['password']);
        $this->session->set('user', $user); $this->session->set('user_id', $user['id']); $this->session->set('user_role', $user['rol_nombre']);
        return true;
    }
    public function check(): bool { return $this->session->has('user'); }
    public function user(): ?array { return $this->session->get('user'); }
    public function hasRole(string $role): bool { return $this->session->get('user_role') === $role; }
    public function logout(): void { $this->session->destroy(); session_start(); $this->session->regenerate(); }
}""",

    "app/Core/Validator.php": """<?php
namespace App\\Core;
class Validator {
    private array $errors = []; private array $data = [];
    public function validate(array $data, array $rules): bool {
        $this->errors = []; $this->data = $data;
        foreach ($rules as $field => $ruleSet) {
            $value = $data[$field] ?? null; $label = ucwords(str_replace('_', ' ', $field));
            foreach (explode('|', $ruleSet) as $rule) {
                if ($rule === 'required' && ($value === null || $value === '')) $this->errors[$field][] = "El campo {$label} es obligatorio";
                if ($rule === 'email' && $value && !filter_var($value, FILTER_VALIDATE_EMAIL)) $this->errors[$field][] = "Email inválido";
                if (strpos($rule, 'min:') === 0 && strlen((string)$value) < (int)substr($rule, 4)) $this->errors[$field][] = "Mínimo " . substr($rule, 4) . " caracteres";
            }
        }
        return empty($this->errors);
    }
    public function errors(): array { return $this->errors; }
}""",

    "app/Core/ErrorHandler.php": """<?php
namespace App\\Core;
class ErrorHandler {
    public static function handle(\\Throwable $e): void {
        $isProd = (getenv('APP_ENV') ?? 'production') === 'production';
        if ($isProd) { http_response_code(500); echo "<h1>Error del servidor</h1>"; } 
        else { http_response_code(500); echo "<h1>Error: " . htmlspecialchars($e->getMessage()) . "</h1><pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>"; }
        exit;
    }
}""",

    "app/Core/Application.php": """<?php
namespace App\\Core;
class Application {
    private static ?Application $instance = null;
    private array $services = []; private Router $router;
    public function __construct() { self::$instance = $this; }
    public static function getInstance(): self { if (self::$instance === null) self::$instance = new self(); return self::$instance; }
    public function registerServices(): void {
        $this->services['db'] = Database::getInstance();
        $this->services['session'] = new Session();
        $this->services['auth'] = new Auth($this->services['db'], $this->services['session']);
        $this->services['validator'] = new Validator();
        $this->router = new Router($this->services['auth']);
        require_once BASE_PATH . '/routes/web.php';
    }
    public function getRouter(): Router { return $this->router; }
    public function getService(string $name) { return $this->services[$name] ?? null; }
    public function run(): void {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/') ?: '/';
        $route = $this->router->resolve($method, $uri);
        if ($route === null) { http_response_code(404); echo "404 No encontrado"; return; }
        if ($route['auth'] && !$this->services['auth']->check()) { redirect('/login'); return; }
        $controller = new $route['controller']();
        $response = call_user_func_array([$controller, $route['method']], $route['params'] ?? []);
        if (is_string($response)) echo $response;
    }
}""",

    "app/Models/Usuario.php": """<?php
namespace App\\Models;
use App\\Core\\Model;
class Usuario extends Model {
    protected static string $table = 'usuarios';
    protected static array $fillable = ['username', 'password', 'nombre_completo', 'email', 'rol_id', 'activo'];
    public static function findByUsername(string $username): ?array {
        return \\App\\Core\\Database::getInstance()->fetchOne("SELECT u.*, r.nombre as rol_nombre FROM usuarios u INNER JOIN roles r ON u.rol_id = r.id WHERE u.username = ?", [$username]);
    }
    public static function createUser(array $data): int {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
        return self::create($data);
    }
}""",

    "app/Models/Producto.php": """<?php
namespace App\\Models;
use App\\Core\\Model;
class Producto extends Model {
    protected static string $table = 'productos';
    protected static array $fillable = ['codigo', 'nombre', 'categoria_id', 'precio_venta', 'stock_minimo', 'requiere_formula', 'activo'];
    public static function allWithCategoria(): array {
        return \\App\\Core\\Database::getInstance()->fetchAll("SELECT p.*, c.nombre as categoria_nombre FROM productos p LEFT JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id DESC");
    }
}""",

    "app/Controllers/AuthController.php": """<?php
namespace App\\Controllers;
use App\\Core\\Controller;
class AuthController extends Controller {
    public function showLogin(): string {
        if ($this->auth->check()) redirect('/dashboard');
        return $this->view('auth/login');
    }
    public function login(): void {
        $this->validateCsrf();
        if ($this->auth->attempt(trim($this->input('username', '')), $this->input('password', ''))) {
            $this->redirect('/dashboard', ['success' => 'Bienvenido']);
        }
        $this->redirect('/login', ['error' => 'Credenciales inválidas']);
    }
    public function logout(): void { $this->auth->logout(); redirect('/login'); }
}""",

    "app/Controllers/DashboardController.php": """<?php
namespace App\\Controllers;
use App\\Core\\Controller;
class DashboardController extends Controller {
    public function index(): string {
        $stats = [
            'total_productos' => $this->db->fetchOne("SELECT COUNT(*) as total FROM productos WHERE activo = 1")['total'],
            'ventas_mes' => $this->db->fetchOne("SELECT COALESCE(SUM(total), 0) as total FROM ventas WHERE MONTH(fecha_venta) = MONTH(CURDATE())")['total']
        ];
        return $this->view('dashboard/index', ['stats' => $stats]);
    }
}""",

    "app/Controllers/ProductoController.php": """<?php
namespace App\\Controllers;
use App\\Core\\Controller;
use App\\Models\\Producto;
class ProductoController extends Controller {
    public function index(): string {
        return $this->view('productos/index', ['productos' => Producto::allWithCategoria()]);
    }
}""",

    "routes/web.php": """<?php
$router = $app->getRouter();
$router->get('/login', \\App\\Controllers\\AuthController::class, 'showLogin');
$router->post('/login', \\App\\Controllers\\AuthController::class, 'login');
$router->get('/logout', \\App\\Controllers\\AuthController::class, 'logout');
$router->get('/', \\App\\Controllers\\DashboardController::class, 'index', ['auth' => true]);
$router->get('/dashboard', \\App\\Controllers\\DashboardController::class, 'index', ['auth' => true]);
$router->get('/productos', \\App\\Controllers\\ProductoController::class, 'index', ['auth' => true]);""",

    "app/Views/layouts/app.php": """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Farmacia UTS') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; background: #1e293b; color: white; }
        .sidebar a { color: #cbd5e1; text-decoration: none; padding: 10px 15px; display: block; }
        .sidebar a:hover, .sidebar a.active { background: #0d6efd; color: white; }
        .card { border: none; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
<div class="d-flex">
    <div class="sidebar p-3" style="width: 250px;">
        <h4 class="text-center mb-4"><i class="bi bi-capsule"></i> Farmacia UTS</h4>
        <a href="<?= url('/dashboard') ?>" class="<?= is_active('/dashboard') ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="<?= url('/productos') ?>" class="<?= is_active('/productos') ?>"><i class="bi bi-box-seam"></i> Productos</a>
        <hr>
        <a href="<?= url('/logout') ?>" class="text-danger"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a>
    </div>
    <div class="flex-grow-1 p-4">
        <?php if ($msg = get_flash('success')): ?>
            <div class="alert alert-success"><?= e($msg) ?></div>
        <?php endif; ?>
        <?php if ($msg = get_flash('error')): ?>
            <div class="alert alert-danger"><?= e($msg) ?></div>
        <?php endif; ?>
        <?= $content ?? '' ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>""",

    "app/Views/auth/login.php": """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Farmacia UTS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { background: white; padding: 2rem; border-radius: 1rem; width: 100%; max-width: 400px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
    <div class="login-card">
        <h3 class="text-center mb-4"><i class="bi bi-capsule text-primary"></i> Farmacia UTS</h3>
        <?php if ($msg = get_flash('error')): ?><div class="alert alert-danger"><?= e($msg) ?></div><?php endif; ?>
        <form method="POST" action="<?= url('/login') ?>">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Usuario</label>
                <input type="text" name="username" class="form-control" required autofocus>
            </div>
            <div class="mb-4">
                <label class="form-label">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
        </form>
        <div class="text-center mt-3"><small class="text-muted">Prueba: admin / admin123</small></div>
    </div>
</body>
</html>""",

    "app/Views/dashboard/index.php": """<?php $title = 'Dashboard'; ob_start(); ?>
<h2>Dashboard</h2>
<p class="text-muted">Bienvenido, <?= e($current_user['nombre_completo'] ?? 'Usuario') ?> (<?= e($current_user['rol_nombre'] ?? 'Rol') ?>)</p>
<div class="row g-3 mt-3">
    <div class="col-md-6">
        <div class="card p-3 border-start border-4 border-primary">
            <h5 class="text-muted">Total Productos</h5>
            <h2 class="mb-0"><?= (int) $stats['total_productos'] ?></h2>
        </
</div>
    <div class="col-md-6">
        <div class="card p-3 border-start border-4 border-success">
            <h5 class="text-muted">Ventas del Mes</h5>
            <h2 class="mb-0"><?= format_currency($stats['ventas_mes']) ?></h2>
        </div>
    </div>
</div>
<?php $content = ob_get_clean(); require BASE_PATH . '/app/Views/layouts/app.php'; ?>""",

    "app/Views/productos/index.php": """<?php $title = 'Productos'; ob_start(); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Productos</h2>
    <button class="btn btn-primary"><i class="bi bi-plus"></i> Nuevo Producto</button>
</div>
<div class="card p-3">
    <table class="table table-hover">
        <thead class="table-light">
            <tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Estado</th></tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $p): ?>
            <tr>
                <td><code><?= e($p['codigo']) ?></code></td>
                <td><?= e($p['nombre']) ?></td>
                <td><?= e($p['categoria_nombre'] ?? 'N/A') ?></td>
                <td><?= format_currency($p['precio_venta']) ?></td>
                <td><span class="badge bg-<?= $p['activo'] ? 'success' : 'secondary' ?>"><?= $p['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php $content = ob_get_clean(); require BASE_PATH . '/app/Views/layouts/app.php'; ?>""",

    "database/schema.sql": """-- Esquema de Base de Datos - Sistema Farmacia UTS
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS farmacia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farmacia;

CREATE TABLE roles (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(50) NOT NULL UNIQUE);
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
    nombre_completo VARCHAR(150) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE, rol_id INT NOT NULL, activo TINYINT(1) DEFAULT 1,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);
CREATE TABLE categorias (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(100) NOT NULL UNIQUE, activo TINYINT(1) DEFAULT 1);
CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY, codigo VARCHAR(50) NOT NULL UNIQUE, nombre VARCHAR(200) NOT NULL,
    categoria_id INT, precio_venta DECIMAL(12,2) NOT NULL DEFAULT 0.00, stock_minimo INT DEFAULT 10,
    requiere_formula TINYINT(1) DEFAULT 0, activo TINYINT(1) DEFAULT 1,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);
CREATE TABLE ventas (
    id INT AUTO_INCREMENT PRIMARY KEY, numero_venta VARCHAR(30) NOT NULL UNIQUE, usuario_id INT NOT NULL,
    fecha_venta DATETIME NOT NULL, total DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Datos iniciales
INSERT INTO roles (nombre) VALUES ('Administrador'), ('Vendedor');
-- Hash BCrypt para 'admin123'
INSERT INTO usuarios (username, password, nombre_completo, email, rol_id) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador del Sistema', 'admin@farmacia.com', 1);
INSERT INTO categorias (nombre) VALUES ('Analgésicos'), ('Antibióticos'), ('Vitaminas');
INSERT INTO productos (codigo, nombre, categoria_id, precio_venta, stock_minimo) VALUES 
('ACET-500', 'Acetaminofén 500mg', 1, 8000.00, 50),
('AMO-500', 'Amoxicilina 500mg', 2, 18000.00, 20);
""",

    "README.md": """# Sistema Web Farmacia - MVC (UTS)
Proyecto de Trabajo de Grado - Tecnología en Desarrollo de Sistemas Informáticos.

## Instalación Rápida
1. Importa `database/schema.sql` en tu MySQL (phpMyAdmin o consola).
2. Copia el archivo `.env` y ajusta `DB_USER` y `DB_PASS` si es necesario.
3. Inicia tu servidor local (XAMPP/Laragon) apuntando a la carpeta `public/`.
4. Accede a: `http://localhost/farmacia/public/`
5. Usuario: `admin` | Contraseña: `admin123`

## Autores
Jaider Javier Jaimes Picón & Jefferson David Aguilar Rojas
Director: Edgar Alfonso Grimaldos Quintero
"""
}

def main():
    print("🚀 Generando estructura del proyecto Farmacia UTS...")
    for filepath, content in PROJECT_FILES.items():
        full_path = os.path.join(os.getcwd(), filepath)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  ✅ Creado: {filepath}")
    
    # Crear carpeta de logs vacía
    os.makedirs(os.path.join(os.getcwd(), 'storage', 'logs'), exist_ok=True)
    print("  ✅ Creado: storage/logs/")
    
    print("\n🎉 ¡PROYECTO GENERADO CON ÉXITO!")
    print("📂 Ubicación:", os.getcwd())
    print("\n📋 PRÓXIMOS PASOS:")
    print("1. Abre phpMyAdmin y ejecuta el archivo: database/schema.sql")
    print("2. Inicia Apache/MySQL en XAMPP o Laragon.")
    print("3. Abre en tu navegador: http://localhost/farmacia/public/")
    print("4. Inicia sesión con: admin / admin123")

if __name__ == "__main__":
    main()